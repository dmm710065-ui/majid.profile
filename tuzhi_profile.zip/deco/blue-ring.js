(function(){
const cv=document.createElement('canvas');
cv.width=160;cv.height=160;
cv.style.position='absolute';
cv.style.top='0';
cv.style.left='0';
document.body.appendChild(cv);
})();